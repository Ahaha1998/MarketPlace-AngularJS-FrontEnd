import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { UsernameValidators } from '../../helper/username.validators';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup

  constructor(private UserService: UserService, private fb: FormBuilder, private route: Router) { 
    this.registerForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3), UsernameValidators.cannotContainSpace]],
      email: ['', [Validators.email, Validators.required]],
      password: '',
      photo: ''
    })
  }

  ngOnInit() {
  }

  registerUser(username, email, password){
    this.UserService.addUser(username, email, password).subscribe(() => {
      this.route.navigate(['/home'])
    })
  }

  // onFileSelected(event){
  //   this.pict = event.target.files[0]
  // }

}
