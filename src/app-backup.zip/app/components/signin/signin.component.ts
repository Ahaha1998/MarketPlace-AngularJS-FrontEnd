import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UsernameValidators } from '../signup-form/username.validators';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  viewMode = 'signin';
  form = new FormGroup({
    username: new FormControl('', [
      Validators.required,
      Validators.minLength(5),
      UsernameValidators.cannotContainSpace
    ],
    UsernameValidators.shouldBeUnique),
    password: new FormControl('', Validators.required)
  });
  login(){
    this.form.setErrors({
      invalidLogin: true
    });
  }
  get username(){
    return this.form.get('username');
  }
  log(x) { console.log(x); }

  submit(f){
    console.log(f);
  }

  constructor() { }

  ngOnInit() {
  }

}
