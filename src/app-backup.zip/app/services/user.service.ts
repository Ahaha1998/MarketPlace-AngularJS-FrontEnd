import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url:string = 'http://localhost:1998';

  constructor(private http: HttpClient) { }

  getUser() {
    return this.http.get(`${this.url}/admin`);
  }

  getUserById(id) {
    return this.http.get(`${this.url}/home/${id}`);
  }

  addUser(username, email, password) {
    const user = {
      username: username,
      email: email,
      password: password
    };
    return this.http.post(`${this.url}/register`, user);
  }

  updateUser(id, username, email, password, photo) {
    const user = {
      username: username,
      email: email,
      password: password,
      photo: photo
    };
    return this.http.post(`${this.url}/home/profile/${id}`, user);
  }

  deleteUser(id) {
    return this.http.get(`${this.url}/admin/${id}`);
  }
}
